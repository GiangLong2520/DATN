﻿namespace Authentication
{
    public class Login
    {
        public void getLoginDetails()
        {

        }
    }
}