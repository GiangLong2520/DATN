﻿namespace HoTroBenhNhanThan
{
    partial class HomeWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        protected System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomeWindow));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_benhAn = new System.Windows.Forms.Button();
            this.btn_staff = new System.Windows.Forms.Button();
            this.btn_Roles = new System.Windows.Forms.Button();
            this.LEFTPANEL.SuspendLayout();
            this.BtnBackPanel.SuspendLayout();
            this.RIGHTPANEL.SuspendLayout();
            this.UserPanel.SuspendLayout();
            this.right_panel.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // right_panel
            // 
            this.right_panel.Controls.Add(this.tableLayoutPanel1);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.button11, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.button10, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.button9, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button8, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.button7, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.button6, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.button5, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.button3, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_benhAn, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_staff, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_Roles, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(949, 689);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // button11
            // 
            this.button11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button11.FlatAppearance.BorderSize = 2;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.ForeColor = System.Drawing.Color.DarkGreen;
            this.button11.Location = new System.Drawing.Point(714, 347);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(232, 166);
            this.button11.TabIndex = 11;
            this.button11.Text = "Roles";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button10.FlatAppearance.BorderSize = 2;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.ForeColor = System.Drawing.Color.DarkGreen;
            this.button10.Location = new System.Drawing.Point(477, 347);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(231, 166);
            this.button10.TabIndex = 10;
            this.button10.Text = "Roles";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button9.FlatAppearance.BorderSize = 2;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.DarkGreen;
            this.button9.Location = new System.Drawing.Point(240, 347);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(231, 166);
            this.button9.TabIndex = 9;
            this.button9.Text = "Roles";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button8.FlatAppearance.BorderSize = 2;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.Color.DarkGreen;
            this.button8.Location = new System.Drawing.Point(3, 347);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(231, 166);
            this.button8.TabIndex = 8;
            this.button8.Text = "Roles";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button7.FlatAppearance.BorderSize = 2;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.DarkGreen;
            this.button7.Location = new System.Drawing.Point(714, 175);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(232, 166);
            this.button7.TabIndex = 7;
            this.button7.Text = "Roles";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button6.FlatAppearance.BorderSize = 2;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.DarkGreen;
            this.button6.Location = new System.Drawing.Point(477, 175);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(231, 166);
            this.button6.TabIndex = 6;
            this.button6.Text = "Roles";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button5.FlatAppearance.BorderSize = 2;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.DarkGreen;
            this.button5.Location = new System.Drawing.Point(240, 175);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(231, 166);
            this.button5.TabIndex = 5;
            this.button5.Text = "Roles";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.FlatAppearance.BorderSize = 2;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.DarkGreen;
            this.button4.Location = new System.Drawing.Point(3, 175);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(231, 166);
            this.button4.TabIndex = 4;
            this.button4.Text = "Roles";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.FlatAppearance.BorderSize = 2;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.DarkGreen;
            this.button3.Location = new System.Drawing.Point(714, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(232, 166);
            this.button3.TabIndex = 3;
            this.button3.Text = "Roles";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_benhAn
            // 
            this.btn_benhAn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_benhAn.FlatAppearance.BorderSize = 2;
            this.btn_benhAn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_benhAn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_benhAn.ForeColor = System.Drawing.Color.DarkGreen;
            this.btn_benhAn.Image = ((System.Drawing.Image)(resources.GetObject("btn_benhAn.Image")));
            this.btn_benhAn.Location = new System.Drawing.Point(477, 3);
            this.btn_benhAn.Name = "btn_benhAn";
            this.btn_benhAn.Size = new System.Drawing.Size(231, 166);
            this.btn_benhAn.TabIndex = 2;
            this.btn_benhAn.Text = "BENHAN";
            this.btn_benhAn.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn_benhAn.UseVisualStyleBackColor = true;
            this.btn_benhAn.Click += new System.EventHandler(this.btn_benhAn_Click);
            // 
            // btn_staff
            // 
            this.btn_staff.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_staff.FlatAppearance.BorderSize = 2;
            this.btn_staff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_staff.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_staff.ForeColor = System.Drawing.Color.DarkGreen;
            this.btn_staff.Image = ((System.Drawing.Image)(resources.GetObject("btn_staff.Image")));
            this.btn_staff.Location = new System.Drawing.Point(240, 3);
            this.btn_staff.Name = "btn_staff";
            this.btn_staff.Size = new System.Drawing.Size(231, 166);
            this.btn_staff.TabIndex = 1;
            this.btn_staff.Text = "STAFF";
            this.btn_staff.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn_staff.UseVisualStyleBackColor = true;
            this.btn_staff.Click += new System.EventHandler(this.btn_staffs_Click);
            // 
            // btn_Roles
            // 
            this.btn_Roles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Roles.FlatAppearance.BorderSize = 2;
            this.btn_Roles.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Roles.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Roles.ForeColor = System.Drawing.Color.DarkGreen;
            this.btn_Roles.Image = ((System.Drawing.Image)(resources.GetObject("btn_Roles.Image")));
            this.btn_Roles.Location = new System.Drawing.Point(3, 3);
            this.btn_Roles.Name = "btn_Roles";
            this.btn_Roles.Size = new System.Drawing.Size(231, 166);
            this.btn_Roles.TabIndex = 0;
            this.btn_Roles.Text = "ROLLS";
            this.btn_Roles.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn_Roles.UseVisualStyleBackColor = true;
            this.btn_Roles.Click += new System.EventHandler(this.btn_Roles_Click);
            // 
            // HomeWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1272, 760);
            this.Name = "HomeWindow";
            this.Text = "HomeWindow";
            this.LEFTPANEL.ResumeLayout(false);
            this.BtnBackPanel.ResumeLayout(false);
            this.RIGHTPANEL.ResumeLayout(false);
            this.UserPanel.ResumeLayout(false);
            this.right_panel.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Button button11;
        private Button button10;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button btn_benhAn;
        private Button btn_staff;
        private Button btn_Roles;
    }
}